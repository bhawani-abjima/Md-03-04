﻿public interface IPlayer
{
    void details();
    void PrintFullName();
}