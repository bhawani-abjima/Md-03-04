﻿using System;

public class Worker
{
    public string WorkerName = "FN";
    public string WorkerId = "LN";

    public virtual void PrintWorkerInfo()               //using virtual keyword
    {
        Console.WriteLine(WorkerName+" "+WorkerId);
    }
}
public class PartTimeWorker:Worker
{

    public override void PrintWorkerInfo()               //using override keyword for method overiding and new for method hiding
    {
        Console.WriteLine(WorkerName + " " + WorkerId+"PartTime");
    }
}
public class FullTimeWorker : Worker
{
    public override void PrintWorkerInfo()
    {
        Console.WriteLine(WorkerName + " " + WorkerId + "FullTime");
    }

}
public class TemporaryWorker : Worker
{
    public override void PrintWorkerInfo()
    {
        Console.WriteLine(WorkerName + " " + WorkerId + "TemparoryTime");
    }
}
public class Employee
{
    public string FirstName;
    public string LastName; 
    public string Email;

    public void PrintFullName()
    {
        Console.WriteLine(FirstName+" "+LastName+" "+Email);
        
    }
}
public class Fulltimeemployee: Employee        //using inheritance
{
    public float yearlysalary;  
    public void Printsalary()
    {
        Console.WriteLine(FirstName + " " + LastName + "Contractor ");
        Console.WriteLine(yearlysalary);
    }

}
public class Parttimeemployee: Employee
{
    public float hourlyrate;
    public void Printrate()
    {
        Console.WriteLine(hourlyrate);
    }
}
class Vehicle  
{
    public string brand = "Ford";  
    public void honk()             
    {
        Console.WriteLine("hmmhrr hmmhrr, ukhmm!");
    }
}

class Car : Vehicle  
{
    public string modelName = "Mustang";  
}


public class PlayerA
{
    public string PlayerName;
    public string Role;


    public void details()
    {
        Console.WriteLine(PlayerName + " " + Role);
    }
}
public class G1status : PlayerA
{
    public float average;
    public void Printavg()
    {
        Console.WriteLine("Average:"+average);
    }
}
public class BaseClass
{
    public virtual void Print()
    {
        Console.WriteLine("I am a base class print ,method");
    }    
}
public class DerviedClass:BaseClass
{
    public new void Print()
    {
        Console.WriteLine("I am a Derived class print ,method");
    }
}

public class Program
{
    public int Add(int a, int b)
    {
        int sum = a + b;
        return sum;
    }
    public int Add(int a, int b, int c)
    {
        int sum = a + b + c;
        return sum;
    }
    public static void Main(string[] args)
    {
        Fulltimeemployee FTE = new Fulltimeemployee();      //class Fulltimeemployee object declaration
        FTE.FirstName = "Adam";
        FTE.LastName = "Eve";
        FTE.yearlysalary = 60000;

        FTE.PrintFullName();
        ((Employee)FTE).PrintFullName();    //Using method overloading technique
        FTE.Printsalary();


        Parttimeemployee PTE = new Parttimeemployee();     //class Fulltimeemployee object declaration
        PTE.FirstName = "Shifu";
        PTE.LastName = "Master";
        PTE.hourlyrate = 600;

        PTE.PrintFullName();
        PTE.Printrate();

        Car myCar = new Car();                             //class car object declaration
        myCar.honk();
        Console.WriteLine(myCar.brand + " " + myCar.modelName);


        G1status PR = new G1status();                      //class player object declaration
        PR.PlayerName = "R.Jadeja";
        PR.Role = "All-Rounder";
        PR.average = 40;
        PR.details();
        PR.Printavg();


        Worker WR = new Worker();
        WR.PrintWorkerInfo();

        Worker[] WTR = new Worker[4];
        WTR[0] = new Worker();
        WTR[1] = new PartTimeWorker();
        WTR[2] = new FullTimeWorker();
        WTR[3] = new TemporaryWorker();

        foreach (Worker w in WTR)
        {
            w.PrintWorkerInfo();
        }

        BaseClass B = new DerviedClass();   //method hiding technique
        B.Print();


        Program ob = new Program();      //method overloading technique

        int sum1 = ob.Add(1, 2);
        Console.WriteLine("sum of the two "
                          + "integer value : " + sum1);

        int sum2 = ob.Add(1, 2, 3);
        Console.WriteLine("sum of the three "
                          + "integer value : " + sum2);
    }
}